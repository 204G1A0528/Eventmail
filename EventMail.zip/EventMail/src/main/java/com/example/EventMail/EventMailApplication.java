package com.example.EventMail;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EventMailApplication {

	public static void main(String[] args) {
		SpringApplication.run(EventMailApplication.class, args);
	}

}
