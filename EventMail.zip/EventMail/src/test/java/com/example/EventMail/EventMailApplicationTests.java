package com.example.EventMail;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EventMailApplicationTests {

	@Test
	void contextLoads() {
	}

}
